#include <juce_core/juce_core.h>

int main (int argc, char* argv[])
{

    // Your code goes here!
    juce::ignoreUnused (argc, argv);

    return 0;
}
